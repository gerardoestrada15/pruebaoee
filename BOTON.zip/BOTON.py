# -*- coding: UTF-8 -*-


import automationhat
from datetime import date
from datetime import datetime
import time
import ipaddress
import requests
import json
import os
import threading
import subprocess

proc = subprocess.Popen(["cat", "/sys/class/net/eth0/address"], stdout=subprocess.PIPE, shell=False)
(eth_mac, err) =proc.communicate()

archivo=open("datos.txt","w")
archivo.close()

three = False
threeprev=False
two = False
twoprev=False
one = False
oneprev=False

deltaT=0
currT=0
prevT=time.time()

	
def escribe(eth_mac,boton,datetime):
	archivo=open("datos.txt","a")
	archivo.write(eth_mac[0:17] )
	archivo.write(" boton" )
	archivo.write(str(boton) )
	archivo.write(" "+datetime+ "\n")
	archivo.close()
	print("Se escribio")
#-----------------------------------------------------------------------------------------

	
while True:
	currT=time.time()
	deltaT=currT-prevT 
	print(deltaT)
	if deltaT > 60:
		print("Uploading...")
		prevT=currT
		os.system('python upload.py')

	three= automationhat.input.three.is_on()
	if three & ( not threeprev):
		nowe = datetime.now()
		date_time = nowe.strftime("%m/%d/%Y, %H:%M:%S")
		print("Boton3",date_time)
		escribe(eth_mac,3,date_time)
	threeprev=three
	#time.sleep(0.5)
	
	two= automationhat.input.two.is_on()
	if two & ( not twoprev):
		nowe = datetime.now()
		date_time = nowe.strftime("%m/%d/%Y, %H:%M:%S")
		
		print("Boton2",date_time)
		escribe(eth_mac,2,date_time)
	twoprev=two
	#time.sleep(0.5)
	
	one= automationhat.input.one.is_on()
	if one & ( not oneprev):
		nowe = datetime.now()
		date_time = nowe.strftime("%m/%d/%Y, %H:%M:%S")		
		print("Boton1",date_time)
		escribe(eth_mac,1,date_time)
	oneprev=one
	time.sleep(0.2)		



